var query;
$(document).ready(function(){
    
    //function for retreving query string
    function getQueryStringValue (key){  
      return decodeURIComponent(window.location.search.replace(new RegExp("^(?:.*[&\\?]" + encodeURIComponent(key).replace(/[\.\+\*]/g, "\\$&") + "(?:\\=([^&]*))?)?.*$", "i"), "$1"));  
    } 
}); 
window.onload = function() {
    document.getElementById('readID').value = '';
    document.getElementById('diagnosis').value = '';
    document.getElementById('notes').value = '';
    document.getElementById('therAd').value = '';

 }



$('.u-form-1 form').on('submit',function(e){
e.preventDefault();
var patientId=$('#readID').val();
var diagnosis=$('#diagnosis').val();

var notes = $('#notes').val();
var therapy = $('#therAd').val();

    //alert (diagnosis + " " + patientId);
    alert ("Button Pressed");
    $.ajax({
      method: 'POST',
      url: 'http://localhost:3000/api/CreateMedicalRecord',
      
      data:{
        
            "$class": "org.ehr.aspatal.CreateMedicalRecord",
            "patient": patientId,
            "doctor": "Doctor001",
            "diagnosis": diagnosis,
            "notes": notes,
            "therapyadvise": therapy,
            "files": [],
            //"transactionId": "",
            //"timestamp": "2021-07-09T12:33:57.312Z"
          
        }
      /*data: {
        "$class": "org.ehr.aspatal.CreateMedicalRecord",
        "patient": "org.ehr.aspatal.Patient#Patient01",
        "doctor": "org.ehr.aspatal.Doctor#Doctor001",
        "diagnosis": diagnosis,
        "notes": notes,
        "therapy": therapy
    }*/
  })
});