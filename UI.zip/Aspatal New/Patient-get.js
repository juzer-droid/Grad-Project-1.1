window.onload = function() {
    document.getElementById('PDiag').value = '';
    document.getElementById('notes').value = '';
    document.getElementById('PtAdvise').value = '';
    document.getElementById('readID').value = '';
    document.getElementById('PName').value = '';
    document.getElementById('bGr').value = '';
    document.getElementById('PDOB').value = '';
    document.getElementById('PreAil').value = '';

 }
$('.u-form-1 form').on('submit',function(e){
    e.preventDefault();
    var id=$('#readID').val();
    $.ajax({
            method: 'GET',
            url: 'http://localhost:3000/api/Patient/'+id,
            success: function(data){
                    
                    var name = data.firstName + " " + data.lastName;
            
                
                    var len = data.medRec.length;
                    var diagnosis = data.medRec[len-1].diagnosis;
                    var notes = data.medRec[len-1].notes;
                    var therapyadvise = data.medRec[len-1].therapyadvise;
                    var DOB = data.DateofBirth;
                    var BG = data.bloodGroup;
                    $.get("http://localhost:3000/api/Patient/"+id, function(data, status){
               
                        //alert("data"+" "+ diagnosis + " " + notes + " " + therapyadvise);
                        $("#PName").val(name);
                        $("#PDiag").val(diagnosis);
                        $("#notes").val(notes);
                        $("#PtAdvise").val(therapyadvise);
                        $("#PDOB").val(DOB);
                        $("#bGr").val(BG);
                        for (var x = 0; x < len-1; x++){
                          var preail = data.medRec[x].diagnosis;
                          $('#PreAil').val(preail) + " ";
                          
                        }

               
                
                
         
               
             
           });
         }
       });
    })
       
    
