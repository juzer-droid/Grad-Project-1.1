window.onload = function() {
    document.getElementById('EmailID').value = '';
    document.getElementById('PID').value = '';
    
 }
$('.u-form-1 form').on('submit',function(e){
    e.preventDefault();
    var id=$('#EmailID').val();
    $.ajax({
            method: 'GET',
            url: 'http://localhost:3000/api/Login/'+id,
            success: function(data){
                    
                    var Pwordd = data.Password
                    

               
                
                 
                   if ($("#PID").val() == Pwordd)
                   {
                     alert("success");
                     window.location.href = "Patient-Records.html";
                   }
                   else
                   {
                     alert("wrong credentials");
                   }
       }
     })
   });
     
    